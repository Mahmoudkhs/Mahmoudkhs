let burger = document.getElementById('burger'),
   nav = document.getElementById('main-nav');

burger.addEventListener('click', function(e) {
   this.classList.toggle('is-open');
   nav.classList.toggle('is-open');
});

function openmenu() {

   const black = document.querySelector('.main-nav');

   black.classList.toggle('is-open');
   burger.classList.toggle('is-open');
}